var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__2b56ee06._.js")
R.c("server/chunks/[root-of-the-server]__743ec67f._.js")
R.m(98324)
R.m(82473)
module.exports=R.m(82473).exports
