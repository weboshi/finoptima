var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__b6dc4c4c._.js")
R.c("server/chunks/ssr/[root-of-the-server]__06581edf._.js")
R.c("server/chunks/ssr/8d35e_next_d1f1fad2._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/8d35e_ba859dab._.js")
R.m(96536)
module.exports=R.m(96536).exports
