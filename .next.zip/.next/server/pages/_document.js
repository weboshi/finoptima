var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__b6dc4c4c._.js")
R.c("server/chunks/ssr/[root-of-the-server]__06581edf._.js")
R.m(6223)
module.exports=R.m(6223).exports
