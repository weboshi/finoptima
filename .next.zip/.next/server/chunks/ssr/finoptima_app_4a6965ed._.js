module.exports=[10759,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},55444,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(10759).default,width:256,height:256}}];

//# sourceMappingURL=finoptima_app_4a6965ed._.js.map