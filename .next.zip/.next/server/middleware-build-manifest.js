globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a32b113fa206bbe4.js",
      "static/chunks/df0e3aacddb3ec67.js",
      "static/chunks/turbopack-8fbad23a2eb437c9.js"
    ],
    "/_error": [
      "static/chunks/721cdb5680859243.js",
      "static/chunks/df0e3aacddb3ec67.js",
      "static/chunks/turbopack-519ec42666092180.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/28cd83dc9a6e751b.js",
    "static/chunks/db6d603cfaa55c35.js",
    "static/chunks/9bb4a11d9c4f936c.js",
    "static/chunks/486ec725e4508841.js",
    "static/chunks/turbopack-183828e66f390ef7.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];