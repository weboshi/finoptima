__turbopack_load_page_chunks__("/_app", [
  "static/chunks/a32b113fa206bbe4.js",
  "static/chunks/df0e3aacddb3ec67.js",
  "static/chunks/turbopack-8fbad23a2eb437c9.js"
])
