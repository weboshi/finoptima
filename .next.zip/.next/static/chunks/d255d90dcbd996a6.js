__turbopack_load_page_chunks__("/_error", [
  "static/chunks/721cdb5680859243.js",
  "static/chunks/df0e3aacddb3ec67.js",
  "static/chunks/turbopack-519ec42666092180.js"
])
